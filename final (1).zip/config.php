<?php
$servername = "localhost";
$username = "creativ2_test";
$password = "Dumas@2000";
$dbname = "creativ2_student";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
