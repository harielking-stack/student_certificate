<?php
session_start();
include 'config.php';
include 'header.php';


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_id = $_POST['student_id'];
    $name = $_POST['name'];
    $course = $_POST['course'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $photo = $_FILES['photo']['name'];
    $certificate = $_FILES['certificate']['name'];

    move_uploaded_file($_FILES['photo']['tmp_name'], "uploads/" . $photo);
    move_uploaded_file($_FILES['certificate']['tmp_name'], "uploads/" . $certificate);

    $query = "INSERT INTO students (student_id, name, course, phone, email, photo, certificate)
              VALUES ('$student_id', '$name', '$course', '$phone', '$email', '$photo', '$certificate')";

    if ($conn->query($query)) {
        echo "Student added successfully!";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<form method="POST" enctype="multipart/form-data">
    <h2>Add Student</h2>
    <input type="text" name="student_id" placeholder="Student ID" required><br>
    <input type="text" name="name" placeholder="Name" required><br>
    <input type="text" name="course" placeholder="Course" required><br>
    <input type="text" name="phone" placeholder="Phone"><br>
    <input type="email" name="email" placeholder="Email"><br>
    <input type="file" name="photo" required><br>
    <input type="file" name="certificate" required><br>
    <button type="submit">Add Student</button>
</form>
